import React from 'react'

const Footer = () => {
  return (
    <div className='footer-wrapper'>
        
    </div>
  )
}

export default Footer